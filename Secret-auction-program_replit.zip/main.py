from replit import clear
#HINT: You can call clear() to clear the output in the console.
from art import logo
print(logo)

bids = {}
bidding_complete = False

def highest_bid(bids):
  highest_amount = 0
  winner = ''
  for bidder in bids:
    bid_amount = bids[bidder]
    if bid_amount > highest_amount:
      highest_amount = bid_amount
      winner = bidder
  print(f'The winner is {winner} with a bid of ${highest_amount}')

while not bidding_complete:
  name = input('what is your name? ')
  price = int(input('what is your bid? $'))
  bids[name] = price
  continue_bid = input("Are there any other bidders? Type 'yes' or 'no' \n")
  if continue_bid == 'no':
    bidding_complete = True
    highest_bid(bids)
  elif continue_bid == 'yes':
    clear()
